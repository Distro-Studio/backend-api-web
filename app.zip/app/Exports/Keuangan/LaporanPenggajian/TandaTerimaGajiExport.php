<?php

namespace App\Exports\Keuangan\LaporanPenggajian;

use Maatwebsite\Excel\Concerns\FromCollection;

class TandaTerimaGajiExport implements FromCollection
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        //
    }
}
