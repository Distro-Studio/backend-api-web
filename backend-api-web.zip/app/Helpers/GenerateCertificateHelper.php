<?php

namespace App\Helpers;


class GenerateCertificateHelper
{
	public static function generateCertificate($data)
	{
		
	}
}