<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class KategoriTukarJadwal extends Model
{
    use HasFactory;
    protected $guarded = ['id'];

    protected $casts = [
        'id' => 'integer',
        'label' => 'string'
    ];

    /**
     * Get all of the tukar_jadwals for the KategoriTukarJadwal
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function tukar_jadwals(): HasMany
    {
        return $this->hasMany(TukarJadwal::class, 'kategori_penukaran_id', 'id');
    }
}
