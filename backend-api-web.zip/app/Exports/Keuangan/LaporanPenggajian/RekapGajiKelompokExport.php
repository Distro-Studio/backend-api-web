<?php

namespace App\Exports\Keuangan\LaporanPenggajian;

use Maatwebsite\Excel\Concerns\FromCollection;

class RekapGajiKelompokExport implements FromCollection
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        //
    }
}
